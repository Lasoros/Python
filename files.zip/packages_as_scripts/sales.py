

def calc_tax():
    pass

def calc_shipping():
    pass


if __name__ == "__main__": #this is a good example of a script file running from only this file as outside of this file
    print("Sales Started") #the name of the file will not longer be __main__
    calc_tax()